#!/usr/bin/env node

//include:
var snap7          = require('node-snap7'); //Siemens S7 ethernet protokoll
var fs             = require('fs');
var XMLHttpRequest = require("xmlhttprequest").XMLHttpRequest;
var argv           = require('process').argv;
var zlib           = require('zlib');

//Globális változók:
var serverConf;
var nodeList;
var Nodes = [];
var nodeInterval = [];
const remanentDataDir = "./data/";
const configFile = 'server.json';
var sw = "";
var reconnectAlert = false;

console.log("WUI Client V1.0");
console.log("  Loglevel 1: " + __filename.split(/\\|\//)[__filename.split(/\\|\//).length -1] + " -v");
console.log("  Loglevel 2: " + __filename.split(/\\|\//)[__filename.split(/\\|\//).length -1] + " -v2\n");

//Kapcsolók értemlezése:
for (let i = 0; i < argv.length; i++) {
  if (argv[i].match(/^\-.+?/)) {
    sw += argv[i];
  }
}

//Megnyitjuk a szerver adatait tartalmazó fájlt:
fs.readFile(remanentDataDir + configFile, 'utf8', function (err, data) {
  serverConf = JSON.parse(data);
  console.log('Szerver url: ' + serverConf.url); //nem titkoljuk a tartalmát
  console.log('Token: ' + serverConf.token);
  if (err) { //ha nem sikerül megnyitni, akkor kilépünk.
    console.log('Nem sikerült megnyitni a konfigurációs fájlt: ' + remanentDataDir + configFile);
    process.exit(); //Kilépünk, de a systemct-nek újra kell indítani a programot.
                    //Tehát reményeink szerint újraindítjuk a scriptet.
  }
  //Ha sikeres a fájl megnyitása, elindítunk pár fontos folyamatot:
  //A szerverrel kapcsolatot tartó függvény:
  serverComm();
});

//Megnyitjuk a nodelist.json fájlt. Ahány PLC, annyi példányt indítunk a megfelelő driverből.
//Ha a fájl nem létezik, vagy hibás, akkor nem csinálunk semmit, hátha leküldi a szerver.
fs.readFile(remanentDataDir + "nodelist.json", 'utf8', function (err, data) {
  if (err) {
    console.log("Nem sikerült megnyitni a nodelist.json fájlt!");
  }
  else {
    try {
      if(nodeList = JSON.parse(data)){
       console.log("NodeList sikeresen betöltve.");
       console.log("  > " + nodeList.node.length + " PLC találat.");
      }
    }
    catch (err) {
      console.log("A nodelist.json nem szabályos JSON fájl!");
    }
    
    if(nodeList) {
      for (let i=0; i < nodeList.node.length; i++) {
        console.log("    > NODE " + i + ":");
        console.log("      > NodeName: " + nodeList.node[i].nodename);
        console.log("      > IP: " + nodeList.node[i].ip);
        console.log("      > Frissítési idő: " + nodeList.node[i].scan);
        console.log("      > Driver: " + nodeList.node[i].driver);
        
        //Ide kell betenni a további kommunikációs driverek hívásait pl.: modBUS:
        if(nodeList.node[i].driver == "snap7"){
          newSnap7node(i);
        }
      }
    }
  }
});

//Definiáljuk a függvényt, ami folyamatos kapcsolatot tart a szerverrel.
//A hosszú lekérési idő (20s) letelte után újra lekérjük.
//Ha a szervernek közlendője van, azt oldalt azonnal visszaadja,
//ez a long polling egy szofisztikáltabb megvalósítása, hasonló szerver -> kliens
//irányú sebesség érhető el, mint a WebSocket-tel, de támogatja a legtöbb webszerver,
//ami képes egy PHP szkriptet huzamosabb ideig futtatni (pl: 20s)
function serverComm() {
  var jsonCommand;
  var xhr = new XMLHttpRequest();
  xhr.onload = () => {
    if(xhr.responseText.length > 0) {
      try {
       jsonCommand = JSON.parse(xhr.responseText);
       if (!jsonCommand.error) {
         var date = new Date();
         console.log("  > Új parancs " + date.toGMTString());
         commander(jsonCommand);
       }
      }
      catch (err) {
        console.log(err);
      }
    }
    else {
      var date = new Date();
      if(sw.match(/\-v/)) console.log("  > Nincs új parancs " + date.toGMTString());
    }
    serverComm();  
  }
  xhr.onerror = () => {
    serverComm();
  }
  xhr.timeout = 30000;
  xhr.open("GET", serverConf.url + '?p=clientcommandrest&token=' + serverConf.token, true);
  xhr.send();
}

//Ez a függvény értelmezi a szerver által "küldött" json utasítást:
function commander(json) {
  //Új nodelist (PLC változólista) érkezett:
  if (json.type == "nodelist") {
    fs.writeFile(remanentDataDir + "nodelist.json", JSON.stringify(json), function (err) {
      if (err) {
        console.log("nodelist.json írási hiba!");
      }
      else {
        console.log("nodelist.json frissítve");
        process.exit(); //Kilépünk, de a systemct-nek újra kell indítani a programot.
                        //Tehát reményeink szerint újraindítjuk a scriptet.
      }
    });
  }
  else if (json.type == "writetag") {
    writeTagInNode(json);
  }
}

//Bájtadatból meghatározzuk az értéket az adattípus alapján:
function getValueFromBuffer(buffer, type){
  if (type.match(/^FloatBE/i)) return floatRound(buffer.readFloatBE(),10);//SIEMENS
  if (type.match(/^FloatLE/i)) return floatRound(buffer.readFloatLE(),10);
  if (type.match(/^Int8/i)) return buffer.readInt8();
  if (type.match(/^UInt8/i)) return buffer.readUInt8();
  if (type.match(/^Int16BE/i)) return buffer.readInt16BE();//SIEMENS
  if (type.match(/^Int16LE/i)) return buffer.readInt16LE();
  if (type.match(/^UInt16BE/i)) return buffer.readUInt16BE();//SIEMENS
  if (type.match(/^UInt16LE/i)) return buffer.readUInt16LE();
  if (type.match(/^Int32BE/i)) return buffer.readInt32BE();//SIEMENS
  if (type.match(/^Int32LE/i)) return buffer.readInt32LE();
  if (type.match(/^UInt32BE/i)) return buffer.readUInt32BE();//SIEMENS
  if (type.match(/^UInt32LE/i)) return buffer.readUInt32LE();
  if (type.match(/^Bit/i)) return buffer.readUInt8();
}


//Bájtadatot hoz létre az érték és az adattípus alapján:
function valueBuffer(value, type){
  var buf = Buffer.allocUnsafe(4);
  if (type.match(/16/)) buf = Buffer.allocUnsafe(2);
  else if (type.match(/8$|^Bit/)) buf = Buffer.allocUnsafe(1);

  value = Number(value);
  if(isNaN(value)) return;

  if (type.match(/^FloatBE/i)){
    if(value > 1.00e+38 || value < -1.00e+38) return;
    buf.writeFloatBE(value);//SIEMENS
  }
  else if (type.match(/^FloatLE/i)){
    if(value > 1.00e+38 || value < -1.00e+38) return;
    buf.writeFloatLE(value);
  }
  else if (type.match(/^Int8/i)){
    if(value > 127 || value < -128) return;
    buf.writeInt8(parseInt(value));
  }
  else if (type.match(/^UInt8/i)){
    if(value > 255 || value < 0) return;
    buf.writeUInt8(parseInt(value));
  }
  else if (type.match(/^Int16BE/i)){
    if(value > 32767 || value < -32768) return;
    buf.writeInt16BE(parseInt(value));//SIEMENS
  }
  else if (type.match(/^Int16LE/i)){
    if(value > 32767 || value < -32768) return;
    buf.writeInt16LE(parseInt(value));
  }
  else if (type.match(/^UInt16BE/i)){
    if(value > 65535 || value < 0) return;
    buf.writeUInt16BE(parseInt(value));//SIEMENS
  }
  else if (type.match(/^UInt16LE/i)){
    if(value > 65535 || value < 0) return;
    buf.writeUInt16LE(parseInt(value));
  }
  else if (type.match(/^Int32BE/i)){
    if(value > 2147483647 || value < -2147483648) return;
    buf.writeInt32BE(parseInt(value));//SIEMENS
  }
  else if (type.match(/^Int32LE/i)){
    if(value > 2147483647 || value < -2147483648) return;
    buf.writeInt32LE(parseInt(value));
  }
  else if (type.match(/^UInt32BE/i)){
    if(value > 4294967295 || value < 0) return;
    buf.writeUInt32BE(parseInt(value));//SIEMENS
  }
  else if (type.match(/^UInt32LE/i)){
    if(value > 4294967295 || value < 0) return;
    buf.writeUInt32LE(parseInt(value));
  }
  else if (type.match(/^Bit/i)){
    if(value) value = 1;
    else value = 0;
    buf.writeUInt8(parseInt(value));
  }
  else return;
  
  return buf;
}



//Kerekítjük a lebegőpontos számot a kért bruttó hosszra:
function floatRound(num, len) {
  var ret = parseFloat(num.toExponential(len - 2));
  //Ha nagyon kicsi a szám, akkor ennek ellenére is exponenciális lesz, de legalább
  //röviddé alakítjuk. Ennyire kicsire nem adunk:
  if (ret.toString().match(/e\-/i)) {
    if(parseInt(ret.toString().split('e-')[1]) > 8){
      if (ret > 0) {
        ret = 0.000000001;
      }
      else {
        ret = -0.000000001;
      }
    }
  }
  return ret;
}


//Periódikus lekérdezések kezelése; ciklusképzés:
function scanNodeMain(funcNodeScan, num) {
  clearInterval(nodeInterval[num]);
  if(nodeList.node[num].scan < 200) { //Ennél sűrűbben nem adunk fel adatot.
    nodeList.node[num].scan = 200;
  }
  setTimeout(() => { //Csökkentjük a szimultán lekérdezések lehetőségét több node esetén.
    nodeInterval[num] = setInterval(() => {funcNodeScan(num)}, nodeList.node[num].scan);
  }, num * 200);
}


function writeTagInNode(json) {
  if (json.nodename && json.data && json.data.type && json.data.addr) {
    for (let i = 0;i < nodeList.node.length;i++) {
      if (nodeList.node[i].nodename == json.nodename){
        if(nodeList.node[i].driver == "snap7"){
          writeTagInS7Node(i, json);
        }
        //Ide jöhet a többi DRIVER!
        break;
      }
    }
  }  
}

//-------------------------------------------------------------------------------------//
//---SIEMENS specifikus függvények-----------------------------------------------------//
//-------------------------------------------------------------------------------------//

//Siemens Beíró függvény:
function writeTagInS7Node(num, json) {
  var s7w = {};
  if (Nodes[num].PlcStatus()) {
    s7w = s7getReadWriteMultiVarsElement(json.data);
    if(valueBuffer(s7w.value, json.data.type) === undefined) return;
    //Nodes[num].WriteArea(area, dbNumber, start, amount, wordLen, buffer[, callback]);
    Nodes[num].WriteArea(s7w.Area, s7w.DBNumber, s7w.Start, s7w.Amount, s7w.WordLen, valueBuffer(s7w.value, json.data.type));
    console.log("Beírás: NODE" + num + ", '" + json.nodename + "', Cím: " + json.data.addr + ", érték: " + s7w.value);
    //Soron kívüli adatfeltöltés az adott node-hoz:
    s7scanNode(num);
  }
}


//SIEMENS kommunikáció (S7 Ethernet) létrehozása:
function newSnap7node(num) {
  Nodes[num] = new snap7.S7Client();
  if(nodeList.node[num].ip.split(',').length == 1){
    nodeList.node[num].ip += ',0,1';
    console.log('Nincs rack és slot kiválasztva.\nAlapérték használata: ' + nodeList.node[num].ip);
  }
  Nodes[num].ConnectTo(nodeList.node[num].ip.split(',')[0], 
                       parseInt(nodeList.node[num].ip.split(',')[1]), 
                       parseInt(nodeList.node[num].ip.split(',')[2]), 
    function(err) {
      if (err) {
        console.log("NODE" + num + " > csatlakozási hiba: " + err);
        //Újracsatlakozás:
        snap7reConnect(num);        
      }
      else {
        console.log("Csatlakozva: NODE" + num);
        scanNodeMain(s7scanNode, num);
      }
    }
  );
}

//Újracsatlakozás SIEMENS PLC-hez:
function snap7reConnect(num) {
  if(!reconnectAlert){
    console.log('Kapcsolat megszakadt, egy vagy több NODE-val. Újracsatlakozás...');
    reconnectAlert = true;
  }
  if(sw.match(/\-v/))console.log("Újracsatlakozás: NODE" + num);
  Nodes[num].ConnectTo(nodeList.node[num].ip.split(',')[0], 
                       parseInt(nodeList.node[num].ip.split(',')[1]), 
                       parseInt(nodeList.node[num].ip.split(',')[2]), 
    function(err) {
      if(err){
        setTimeout(() => {
          snap7reConnect(num);
        }, 2000);
      }
      else {
        console.log("Újracsatlakozás sikeres: NODE" + num);
        reconnectAlert = false;
        scanNodeMain(s7scanNode, num);
      }
    }
  );
}

//A konkrét lekérdezés:
function s7scanNode(num) {
  if (Nodes[num].PlcStatus()) { //A Connected() nem működik. Így lehet lekérdezni hogy van e élő kapcsolat.
    if(sw.match(/\-v/))console.log("NODE" + num + " lekérdezése...");
    var now = [];
    now[num] = Date.now();
    var tmpData = [];
    var dataCount = nodeList.node[num].data.length;
    for (let i = 0; i < dataCount; i++) {
      tmpData[i] = s7getReadWriteMultiVarsElement(nodeList.node[num].data[i]);
    }
    var tmpSlice = [];
    var slice2 = 0;
    var sliceLen = 0;
    for (let i = 0; i < dataCount; i += 19) { //19 értéket lehet biztonsággal kiolvasni a ReadMultiVar-ral.
      slice2 = ((i + 19) > dataCount) ? dataCount : (i + 19);
      tmpSlice = tmpData.slice(i, slice2);
      sliceLen = tmpSlice.length;
      tmpSlice = Nodes[num].ReadMultiVars(tmpSlice);
      if (sliceLen != tmpSlice.length) return; //Ha nem kapunk meg minden adatot, vagy hiba van, inkább kilépünk.
      for (let j = i; j < slice2; j++) {
        tmpData[j].value = tmpSlice[j - i].Data;
      }
    }
    var response = [];
    for (let i = 0; i < tmpData.length; i++) {
      response[i] = {addr: tmpData[i].Address, type: tmpData[i].Type, value: getValueFromBuffer(tmpData[i].value,tmpData[i].Type)};
    }
    
    if(sw.match(/\-v/))console.log("NODE" + num + " lekérdezés ideje [ms]: " + (Date.now() - now[num]));
    
    if(sw.match(/\-v2/)) {
      console.log(response);
    }
    
    now[num] = Date.now();
    var xhr = new XMLHttpRequest();
    xhr.onload  = () => {
      if(sw.match(/\-v/))console.log("NODE" + num + " feltöltés ideje [ms]: " + (Date.now() - now[num]));
    }
    xhr.open('POST', serverConf.url + '?p=clientuploadrest&token=' + serverConf.token, true);
    xhr.setRequestHeader("Content-Type", "application/json;charset=UTF-8");
    xhr.setRequestHeader('Content-Encoding', 'gzip');
    var toSend = "{\"nodename\": \"" + nodeList.node[num].nodename + "\", \"data\": " + JSON.stringify(response) + "}";
    zlib.gzip(toSend, (err, buffer) => {
      if(sw.match(/\-v/))console.log("NODE" + num + " feltöltési tömörített méret [byte]: " + 
       buffer.length + " [" + 
       floatRound((buffer.length/toSend.length) * 100, 4) + "%]");
      xhr.send(buffer);      
    });

  }
  else {
    clearInterval(nodeInterval[num]);
    snap7reConnect(num);
  }
}


//Visszatér egy ReadMultiVar hash elemmel, kiegészítve azt egy 'value' mezővel,
//ahova majd az adat fog kerülni (először buffer-ként).
//Meghatározza az Area, a WordLen, a DBNumber és a Start értéket is:
function s7getReadWriteMultiVarsElement (element) {
  var area;
  var wordLen;
  var start;
  var dbnumber = 0;
  var value = null;
  //A címből reguláris kifejezésekkel döntjük el a fenti feladatokat:
  if (element.addr.match(/^DB/i)) {
    area = Nodes[0].S7AreaDB;
    if (element.addr.match(/DBX/i)) {
      wordLen = Nodes[0].S7WLBit;
    }
    if (element.addr.match(/DBB/i)) {
      wordLen = Nodes[0].S7WLByte;
    }
    if (element.addr.match(/DBW/i)) {
      wordLen = Nodes[0].S7WLWord;
    }
    if (element.addr.match(/DBD/i)) {
      wordLen = Nodes[0].S7WLDWord;
    }
    dbnumber = parseInt(element.addr.match(/DB(\d+)/i)[1]);
  }
  
  if (element.addr.match(/^I/i) || element.addr.match(/^E/i)) {
    area = Nodes[0].S7AreaPE;
    if (element.addr.match(/^I\d/i) || element.addr.match(/^E\d/i)) {
      wordLen = Nodes[0].S7WLBit;
    }
    if (element.addr.match(/B/i)) {
      wordLen = Nodes[0].S7WLByte;
    }
    if (element.addr.match(/W/i)) {
      wordLen = Nodes[0].S7WLWord;
    }
    if (element.addr.match(/D/i)) {
      wordLen = Nodes[0].S7WLDWord;
    }
  }

  if (element.addr.match(/^Q/i) || element.addr.match(/^A/i)) {
    area = Nodes[0].S7AreaPA;
    if (element.addr.match(/^Q\d/i) || element.addr.match(/^A\d/i)) {
      wordLen = Nodes[0].S7WLBit;
    }
    if (element.addr.match(/B/i)) {
      wordLen = Nodes[0].S7WLByte;
    }
    if (element.addr.match(/W/i)) {
      wordLen = Nodes[0].S7WLWord;
    }
    if (element.addr.match(/D/i)) {
      wordLen = Nodes[0].S7WLDWord;
    }
  }

  if (element.addr.match(/^M/i)) {
    area = Nodes[0].S7AreaMK;
    if (element.addr.match(/^M\d/i)) {
      wordLen = Nodes[0].S7WLBit;
    }
    if (element.addr.match(/B/i)) {
      wordLen = Nodes[0].S7WLByte;
    }
    if (element.addr.match(/W/i)) {
      wordLen = Nodes[0].S7WLWord;
    }
    if (element.addr.match(/D/i)) {
      wordLen = Nodes[0].S7WLDWord;
    }
  }
  
  if (wordLen == Nodes[0].S7WLBit) {
    var tmp = element.addr.match(/[\d\.]+$/)[0];
    tmp = tmp.split('.');
    start = (parseInt(tmp[0]) * 8) + parseInt(tmp[1]);
  }
  else {
    start = parseInt(element.addr.match(/[\d\.]+$/));
  }
  
  if(element.value) value = element.value;
  
  return {Area: area,
          WordLen: wordLen, 
          Start: start,
          Amount: 1, 
          DBNumber: dbnumber, 
          value: element.value, 
          Address: element.addr, 
          Type: element.type
  };

}









/*var s7c = new snap7.S7Client();
s7c.ConnectTo('192.168.100.171', 0, 1, function(err) {
    if(err)
        return console.log(' >> Connection failed. Code #' + err + ' - ' + s7c.ErrorText(err));
        
    // Read the first byte from PLC process outputs...
    s7c.ReadArea(s7c.S7AreaPA, 0, 0, 1, s7c.S7WLBit, function(err, res) {
        if(err)
            return console.log(' >> ABRead failed. Code #' + err + ' - ' + s7c.ErrorText(err));

        // ... and write it to stdout
        //console.log(res);
	      console.log(res);
        console.log(res.readUInt8(0));
    });
});*/
