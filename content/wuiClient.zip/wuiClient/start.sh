while [ true ]
do
  node wuiclient.js
  echo "Újraindítás..."
done
